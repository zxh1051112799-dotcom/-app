# CourtVision 网球视频分析

CourtVision 是一个帮助网球爱好者按固定手机机位拍摄、回看训练视频并记录落点的原型。欢迎试用并通过 GitHub Issues 提交建议。

## 在线公开体验

GitHub Pages 预期地址：<https://zxh1051112799-dotcom.github.io/brown/>。首次发布前，请在仓库 **Settings → Pages → Build and deployment → Source** 选择 **GitHub Actions**；之后每次推送到 `main` 会自动更新网站。

公开版可选底线后方或侧边中场机位模板，在浏览器内预览视频、手动标记球场落点并记录测速设备读数。视频在浏览器本地处理，不会上传到此网站。

**当前在线版不含自动 AI 落点识别或球速计算。** 公开版是用于收集建议的轻量体验。自动检测原型需要用户在自己的电脑启动本地服务，见下文。

## 本机 AI 原型

1. 双击 `start-local-ai.command`，等待首次依赖安装完成。
2. 打开 <http://127.0.0.1:8000/>。
3. 上传 MP4 或 MOV，查看上传进度，点击“AI 查找球体候选”。

也可以按 [`README_LOCAL_AI.md`](README_LOCAL_AI.md) 手动安装并启动本地服务。

模型使用 TorchVision COCO SSD-MobileNet 的通用 `sports ball` 类别，按约 4 fps 检索候选。它可能漏掉高速小球或识别到静止球。候选坐标是视频画面坐标，不是球场坐标；当前版本不会自动判断触地或计算球速。真实落点分析还需要机位标定、网球专项追踪模型和轨迹验证。

本机服务仅监听 `127.0.0.1`，默认不可从互联网访问。视频由本机服务处理，并在分析结束或取消后清理临时文件。

## 反馈与开发

- [提交功能建议或体验反馈](https://github.com/zxh1051112799-dotcom/brown/issues/new/choose)
- 本地网页开发：`pnpm install` 后运行 `pnpm dev`
- 网页构建：`pnpm build`
- AI 接口说明：[`AI_INTEGRATION.md`](AI_INTEGRATION.md)
