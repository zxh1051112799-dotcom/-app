# CourtVision AI 落点识别接口

本地原型已连接 AI 分析服务。当前通用模型返回视频中的球体候选；经训练验证的网球模型、触地判断和场地坐标还需要后续实现。

## 请求

`POST {AI_API_ENDPOINT}`，使用 `multipart/form-data`：

- `video`: 用户选择的视频文件
- `camera_template`: `baseline` 或 `sideline`

网页通过 XHR 显示视频上传进度；取消请求时，本机服务会在当前推理步骤中止任务并清理临时视频。模型计算阶段显示已用时间和粗略估时，不是逐帧百分比进度。

建议服务端校验视频类型、时长和大小，并异步处理长视频。生产部署应使用 HTTPS、限制上传体积、设置过期删除策略，避免长期保留原视频。

## 响应

```json
{
  "detections": [
    {
      "timestamp": 4.283,
      "x": 0.72,
      "y": 0.34,
      "confidence": 0.91
    }
  ],
  "coordinateSpace": "frame_normalized",
  "sampleFps": 4,
  "candidateOnly": true
}
```

- `timestamp`: 视频内候选球所在帧时间，单位秒
- `x`, `y`: 当前本地模型的画面归一化位置，支持 `0..1` 或 `0..100`；若要给球场坐标，需先完成机位标定并将 `coordinateSpace` 设为 `court_normalized`
- `confidence`: 通用模型的检测分数，`0..1`；不代表触地判断置信度
- `speedKmh`: 可选的球速估算值。当前本地原型不返回此字段

当前本地服务返回的坐标位于视频画面 (`coordinateSpace: frame_normalized`)，并标记 `candidateOnly: true`。网页显示 AI 候选时间和置信度；它不会把画面坐标伪装成球场落点。场地图仍可供用户人工示意标注。导出的 CSV 会注明坐标用途。

## 模型流程

建议服务端先检测球场并校准透视，再逐帧检测和跟踪网球；结合轨迹速度变化、球与场地平面的交点以及连续帧证据判断触地事件。检测到的候选落点应输出置信度，低置信度结果交给用户复核。两种机位需分别采集代表性视频验证，不能只凭网页机位名称推断真实场地坐标。

本地运行方式见 `README_LOCAL_AI.md`。部署其他服务后，在网页脚本顶部把 `AI_API_ENDPOINT` 指向该服务的 HTTPS 地址。
