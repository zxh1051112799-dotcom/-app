import { useEffect, useRef, useState, type MouseEvent } from 'react'

type CameraMode = 'baseline' | 'sideline'

const templates: { id: CameraMode; title: string; subtitle: string; tag: string; icon: string; details: string[] }[] = [
  { id: 'baseline', title: '底线后方', subtitle: '发球 · 纵向落点', tag: '推荐入门', icon: '▤', details: ['站在底线后方约 3–6 米', '尽量拍入完整球场与两端底线', '允许小幅左右平移跟拍'] },
  { id: 'sideline', title: '侧边中场', subtitle: '对拉 · 横向落点', tag: '全场视角', icon: '▥', details: ['站在边线中点外侧', '让近远两侧边线尽量完整入镜', '跟拍时保持拍摄者原地不动'] },
]

function CourtDiagram({ mode }: { mode: CameraMode }) {
  return <div className={`court-diagram ${mode}`} aria-label="网球场机位示意图"><div className="court"><i className="net" /><i className="service one" /><i className="service two" /><i className="center one" /><i className="center two" /><span className="player p1" /><span className="player p2" /><span className="ball" /></div><span className="phone">▣</span><span className="view-label">手机机位</span></div>
}

function App() {
  const [mode, setMode] = useState<CameraMode>('baseline')
  const [fileName, setFileName] = useState('')
  const [analyzed, setAnalyzed] = useState(false)
  const [videoUrl, setVideoUrl] = useState('')
  const [speed, setSpeed] = useState('')
  const [landings, setLandings] = useState<{ x: number; y: number; timeSeconds: number }[]>([])
  const fileInput = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const selected = templates.find((item) => item.id === mode)!

  useEffect(() => () => {
    if (videoUrl) URL.revokeObjectURL(videoUrl)
  }, [videoUrl])

  function chooseFile(file?: File) {
    if (!file) return
    if (videoUrl) URL.revokeObjectURL(videoUrl)
    setVideoUrl(URL.createObjectURL(file))
    setFileName(file.name)
    setAnalyzed(false)
    setLandings([])
  }

  function markLanding(event: MouseEvent<HTMLDivElement>) {
    const bounds = event.currentTarget.getBoundingClientRect()
    setLandings((current) => [...current, {
      x: Math.max(0, Math.min(100, ((event.clientX - bounds.left) / bounds.width) * 100)),
      y: Math.max(0, Math.min(100, ((event.clientY - bounds.top) / bounds.height) * 100)),
      timeSeconds: videoRef.current?.currentTime ?? 0,
    }])
  }

  function exportSession() {
    const record = {
      project: 'CourtVision',
      exportedAt: new Date().toISOString(),
      fileName,
      cameraTemplate: selected.title,
      speedKmh: speed ? Number(speed) : null,
      landingPoints: landings.map((point, index) => ({ index: index + 1, timeSeconds: Number(point.timeSeconds.toFixed(2)), xPercent: Number(point.x.toFixed(2)), yPercent: Number(point.y.toFixed(2)) })),
      note: '此记录为手动标注；网页没有自动识别球速或落点。',
    }
    const url = URL.createObjectURL(new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' }))
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `courtvision-${new Date().toISOString().slice(0, 10)}.json`
    anchor.click()
    URL.revokeObjectURL(url)
    setAnalyzed(true)
  }

  return <main className="app-shell">
    <header className="topbar"><a className="brand" href="#home"><span className="brand-mark">C</span><span>COURTVISION<small>球迹 · 网球视频分析</small></span></a><nav><a href="#workflow">使用流程</a><a href="#templates">机位模板</a><a href="https://github.com/zxh1051112799-dotcom/brown/issues/new/choose" target="_blank" rel="noreferrer">提交建议</a></nav><button className="top-cta" onClick={() => fileInput.current?.click()}>开始体验 <span>↗</span></button></header>
    <section className="hero" id="home"><div className="hero-copy"><div className="eyebrow"><span className="live-dot" /> 网球训练视频分析 · 公开体验版</div><h1>每一拍，<br /><em>都看得更清楚。</em></h1><p>先用手机跟拍模板拍摄，再在浏览器里预览视频、手动标记落点并记录球速读数。欢迎试用并告诉我们哪些地方最需要改进。</p><div className="hero-actions"><button className="primary" onClick={() => fileInput.current?.click()}>上传训练视频 <span>↑</span></button><a href="https://github.com/zxh1051112799-dotcom/brown/issues/new/choose" target="_blank" rel="noreferrer" className="text-link">给我们提建议 <span>↗</span></a></div><div className="hero-note"><span className="note-icon">✳</span><span><b>适配手机跟拍</b><small>支持小幅平移 · 暂不建议变焦或走动</small></span></div></div><div className="hero-art"><div className="art-top"><span>COURT 01 / LIVE VIEW</span><span className="record"><i /> CAMERA READY</span></div><div className="court-illustration"><div className="court-lines"><i className="line vertical"/><i className="line horizontal h1"/><i className="line horizontal h2"/><i className="line horizontal h3"/><i className="line horizontal h4"/><i className="line service-left"/><i className="line service-right"/><i className="net-line"/><span className="trajectory t1"/><span className="trajectory t2"/><span className="trajectory t3"/><span className="track-ball"/><span className="landing-point"/></div><div className="speed-chip"><span>球速记录</span><b>— <small>km/h</small></b><small>填写测速设备读数</small></div><div className="landing-chip"><span className="landing-dot"/><span>手动标注落点</span></div></div><div className="art-footer"><span>CAMERA TEMPLATE</span><strong>{mode === 'baseline' ? 'BASELINE · 底线后方' : 'SIDELINE · 侧边中场'}</strong><span className="frame-count">VIDEO ANALYSIS <b>01</b></span></div></div></section>
    <section className="template-section" id="templates"><div className="section-heading"><div><div className="eyebrow muted">01 / CAMERA SETUP</div><h2>选一个机位，<em>开始记录。</em></h2></div><p>固定拍摄位置和取景规则，能让场地标定更稳定，分析结果也更值得参考。</p></div><div className="template-grid">{templates.map((item, index) => <button key={item.id} className={`template-card ${mode === item.id ? 'selected' : ''}`} onClick={() => setMode(item.id)}><div className="card-top"><span className="template-index">0{index + 1} / TEMPLATE</span><span className="radio">{mode === item.id ? '✓' : ''}</span></div><CourtDiagram mode={item.id}/><div className="template-title"><span><b>{item.title}</b><small>{item.subtitle}</small></span><span className="tag">{item.tag}</span></div><ul>{item.details.map((detail) => <li key={detail}><span>✓</span>{detail}</li>)}</ul></button>)}</div></section>
    <section className="workflow" id="workflow"><div className="workflow-head"><div><div className="eyebrow muted">02 / YOUR WORKFLOW</div><h2>从视频到记录，<em>三步完成。</em></h2></div><span className="flow-caption">少一点猜测，多一点依据。<b>↘</b></span></div><div className="steps"><article><span className="step-no">01</span><div className="step-icon">▣</div><h3>按模板拍摄</h3><p>选择底线或侧边机位，跟随屏幕提示完成取景。</p></article><div className="step-arrow">→</div><article><span className="step-no">02</span><div className="step-icon">⌖</div><h3>浏览器预览</h3><p>视频仅在当前设备预览，不会上传到分析服务器。</p></article><div className="step-arrow">→</div><article><span className="step-no">03</span><div className="step-icon">⌁</div><h3>手动标记</h3><p>点选球场图记录落点，填写测速设备读数并提交建议。</p></article></div></section>
    <section className="upload-section"><div className="upload-copy"><div className="eyebrow">03 / VIDEO WORKSPACE</div><h2>上传视频，<br />开始手动标注。</h2><p>视频只在当前浏览器本地预览，不会上传。选择一个机位模板，暂停到触地点后在右侧球场图上点击，标记会关联当前视频时间；球速栏可填测速设备读数。在线公开版暂不提供自动 AI 判球。</p><div className="upload-meta"><span>MP4 · MOV</span><span>视频仅在本机预览</span><span>文件留在本机</span></div></div><div className="upload-box workspace" onDragOver={(event) => event.preventDefault()} onDrop={(event) => { event.preventDefault(); chooseFile(event.dataTransfer.files[0]) }}><input ref={fileInput} type="file" accept="video/mp4,video/quicktime,video/*" hidden onChange={(event) => chooseFile(event.target.files?.[0])}/>{!videoUrl ? <><span className="upload-symbol">↑</span><b>把训练视频放在这里</b><small>拖拽文件到此处，或从设备中选择</small><button className="primary" onClick={() => fileInput.current?.click()}>选择视频 <span>↗</span></button></> : <div className="workspace-content"><div className="video-panel"><div className="workspace-toolbar"><span><i className="live-dot" /> VIDEO PREVIEW</span><button className="reset" onClick={() => fileInput.current?.click()}>更换视频</button></div><video ref={videoRef} src={videoUrl} controls playsInline/><div className="file-label">{fileName}</div></div><div className="annotator"><div className="workspace-toolbar"><span>落点标注 · {selected.title}</span><button className="reset" onClick={() => setLandings([])}>清空</button></div><div className={`marking-court ${mode}`} onClick={markLanding} role="button" tabIndex={0} aria-label="点击球场图标记落点">{landings.map((point, index) => <span key={index} className="mark-point" title={`${point.timeSeconds.toFixed(2)} 秒`} style={{ left: `${point.x}%`, top: `${point.y}%` }}>{index + 1}</span>)}</div><small className="mark-hint">暂停在落地画面后点击球场图；每个标记会记录视频时间</small><label className="speed-input">球速读数 <span><input type="number" min="0" max="300" placeholder="—" value={speed} onChange={(event) => setSpeed(event.target.value)}/> km/h</span></label><div className="manual-summary"><b>{landings.length}</b><span>个落点</span><button className="primary save-button" onClick={exportSession}>导出 JSON 记录 <span>↓</span></button></div>{analyzed && <div className="result-hint">已保存本次人工标注：{landings.length} 个落点{speed ? ` · 球速读数 ${speed} km/h` : ''}。自动球速与轨迹识别尚未接入。</div>}</div></div>}</div></section>
    <footer><a className="brand" href="#home"><span className="brand-mark">C</span><span>COURTVISION<small>球迹 · 网球视频分析</small></span></a><span>为每一次练习，留下看得见的进步。</span><a className="footer-right" href="https://github.com/zxh1051112799-dotcom/brown/issues/new/choose" target="_blank" rel="noreferrer">提交建议 · GitHub ↗</a></footer>
  </main>
}

export default App
