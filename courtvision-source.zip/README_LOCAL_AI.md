# 本机 AI 试运行

## 启动

双击 `start-local-ai.command`，或在项目目录运行：

```sh
python3 -m pip install -r requirements-local-ai.txt
python3 -m uvicorn server.main:app --host 127.0.0.1 --port 8000
```

然后打开 <http://127.0.0.1:8000/>，上传视频并点“AI 查找球体候选”。网页显示上传进度、粗略耗时，可在分析中取消；服务会中断当前推理并删除临时视频。首次安装会下载 PyTorch/TorchVision 依赖及约 14 MB 的 COCO SSD-MobileNet 权重；Apple Silicon 可尝试使用 MPS，否则用 CPU。

## 当前能力边界

第一阶段使用 TorchVision 的 COCO SSD-MobileNet 通用 `sports ball` 类别，按 4 fps 对重叠画面裁片找球体候选。它不是网球专用模型，可能漏掉高速小球或误报静止球。候选点是**视频画面归一化坐标**，不是球场坐标，也没有声称检测到触地或计算球速。网页里的球场图只用于人工示意标注。要得到真实落点和球速，下一步需要给两种机位分别做场地四角标定、训练/验证网球追踪模型，再根据球轨迹的触地时刻换算坐标。

最大文件 500 MB；暂时只支持常见本地视频格式。提高抽帧频率会增加推理时间，可通过 `COURTVISION_SAMPLE_FPS=8` 调整。
