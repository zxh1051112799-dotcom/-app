#!/bin/zsh
cd "$(dirname "$0")"
DEFAULT_PYTHON="/Users/apple/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
PYTHON="${COURTVISION_PYTHON:-$DEFAULT_PYTHON}"
if [[ ! -x "$PYTHON" ]]; then PYTHON="python3"; fi
if ! "$PYTHON" -c 'import fastapi,torch,torchvision,imageio_ffmpeg' >/dev/null 2>&1; then
  echo "First run: installing local AI packages (this may take several minutes)..."
  "$PYTHON" -m pip install -r requirements-local-ai.txt || exit 1
fi
exec "$PYTHON" -m uvicorn server.main:app --host 127.0.0.1 --port 8000
