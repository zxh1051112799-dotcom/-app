"""Local CourtVision prototype: generic sports-ball candidates, not bounce labels."""
from __future__ import annotations

import asyncio
import os
import subprocess
import tempfile
import threading
import time
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from PIL import Image
from starlette.concurrency import run_in_threadpool

ROOT = Path(__file__).resolve().parent.parent
MAX_BYTES = 500 * 1024 * 1024
SAMPLE_FPS = float(os.getenv("COURTVISION_SAMPLE_FPS", "4"))
THRESHOLD = float(os.getenv("COURTVISION_THRESHOLD", "0.35"))

app = FastAPI(title="CourtVision local analyzer")


@app.get("/")
def home():
    return FileResponse(ROOT / "preview-v2.html")


def _detect(video_path: Path, work: Path, cancelled: threading.Event) -> list[dict]:
    """Sample at 4 fps, run COCO sports-ball detection on overlapping image tiles."""
    try:
        import torch
        from torchvision.models.detection import SSDLite320_MobileNet_V3_Large_Weights, ssdlite320_mobilenet_v3_large
        from torchvision.transforms.functional import to_tensor
        import imageio_ffmpeg
    except ImportError as exc:
        raise HTTPException(503, "AI dependencies are not installed. Follow README_LOCAL_AI.md") from exc

    frames = work / "frames"
    frames.mkdir()
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(video_path), "-vf", f"fps={SAMPLE_FPS}", "-q:v", "3", str(frames / "frame-%06d.jpg")]
    process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    while process.poll() is None:
        if cancelled.is_set():
            process.terminate()
            process.communicate()
            raise InterruptedError("Analysis cancelled")
        time.sleep(0.2)
    _, stderr = process.communicate()
    if process.returncode:
        raise HTTPException(422, f"Could not decode video: {stderr[-500:]}")
    if cancelled.is_set():
        raise InterruptedError("Analysis cancelled")

    weights = SSDLite320_MobileNet_V3_Large_Weights.DEFAULT
    model = ssdlite320_mobilenet_v3_large(weights=weights).eval()
    if cancelled.is_set():
        raise InterruptedError("Analysis cancelled")
    device = torch.device("mps" if torch.backends.mps.is_available() else "cpu")
    model.to(device)
    ball_class = weights.meta["categories"].index("sports ball")
    detections: list[dict] = []

    with torch.inference_mode():
        for frame_index, frame_path in enumerate(sorted(frames.glob("*.jpg"))):
            if cancelled.is_set():
                raise InterruptedError("Analysis cancelled")
            image = Image.open(frame_path).convert("RGB")
            width, height = image.size
            # Four overlapping crops retain more pixels for the small ball.
            boxes = [
                (0, 0, width * 0.55, height * 0.55),
                (width * 0.45, 0, width, height * 0.55),
                (0, height * 0.45, width * 0.55, height),
                (width * 0.45, height * 0.45, width, height),
            ]
            crops = [image.crop(tuple(map(int, box))) for box in boxes]
            batch = [to_tensor(crop).to(device) for crop in crops]
            outputs = model(batch)
            timestamp = frame_index / SAMPLE_FPS
            frame_candidates = []
            for crop, box, output in zip(crops, boxes, outputs):
                for b, label, score in zip(output["boxes"].cpu(), output["labels"].cpu(), output["scores"].cpu()):
                    if int(label) != ball_class or float(score) < THRESHOLD:
                        continue
                    x1, y1, x2, y2 = map(float, b.tolist())
                    left, top, right, bottom = box
                    x = (left + (x1 + x2) / 2) / width
                    y = (top + (y1 + y2) / 2) / height
                    # Suppress duplicate detections at overlapping crop edges.
                    if any(abs(x - item["x"]) < 0.025 and abs(y - item["y"]) < 0.025 for item in frame_candidates):
                        continue
                    frame_candidates.append({"timestamp": timestamp, "x": x, "y": y, "confidence": float(score)})
            detections.extend(frame_candidates)
    return detections


@app.post("/api/analyze")
async def analyze(request: Request, video: UploadFile = File(...), camera_template: str = Form("baseline")):
    if camera_template not in {"baseline", "sideline"}:
        raise HTTPException(422, "camera_template must be baseline or sideline")
    suffix = Path(video.filename or "video.mp4").suffix.lower()
    if suffix not in {".mp4", ".mov", ".m4v", ".avi", ".mkv"}:
        raise HTTPException(415, "Supported formats: MP4, MOV, M4V, AVI, MKV")
    with tempfile.TemporaryDirectory(prefix="courtvision-") as directory:
        work = Path(directory)
        video_path = work / f"input{suffix}"
        size = 0
        with video_path.open("wb") as output:
            while chunk := await video.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_BYTES:
                    raise HTTPException(413, "Video exceeds the 500 MB local limit")
                output.write(chunk)
        if size == 0:
            raise HTTPException(400, "Uploaded video is empty")
        cancelled = threading.Event()
        task = asyncio.create_task(run_in_threadpool(_detect, video_path, work, cancelled))
        while not task.done():
            if await request.is_disconnected():
                cancelled.set()
            await asyncio.sleep(0.2)
        try:
            detections = await task
        except InterruptedError:
            return JSONResponse(status_code=499, content={"detail": "Analysis cancelled"})
    return {"detections": detections, "coordinateSpace": "frame_normalized", "sampleFps": SAMPLE_FPS, "model": "torchvision-coco-sports-ball", "candidateOnly": True}


@app.get("/api/health")
def health():
    try:
        import torch
        import torchvision
        return {"status": "ready", "torch": torch.__version__, "torchvision": torchvision.__version__, "device": "mps" if torch.backends.mps.is_available() else "cpu"}
    except ImportError:
        return {"status": "dependencies_missing"}
